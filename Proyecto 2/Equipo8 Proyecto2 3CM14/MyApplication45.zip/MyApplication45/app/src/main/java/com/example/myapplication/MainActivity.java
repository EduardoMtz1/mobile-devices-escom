package com.example.myapplication;
import android.app.ListActivity;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;

import android.content.Intent;

import android.os.AsyncTask;
import android.os.Bundle;

import android.util.Log;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ArrayAdapter;
import android.widget.Button;


import android.widget.ListView;

import android.widget.Toast;
import android.widget.ToggleButton;


import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;

import java.util.Set;
import java.util.UUID;

public class MainActivity extends ListActivity {
    private ArrayAdapter<String> mArrayAdapter;
    private BluetoothAdapter mBluetoothAdapter;
    private BluetoothSocket btSocket;
    private ArrayList<BluetoothDevice> btDeviceArray = new ArrayList<BluetoothDevice>();
    private ConnectAsyncTask connectAsyncTask;
    private BluetoothAdapter mBTAdapter;
    static final UUID myUUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    ToggleButton btn1;
    byte[] buffer = new byte[256];
    WebSettings ws;
    WebView wv;
    String s="https://catkin-complex-couch.glitch.me/";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mBTAdapter = BluetoothAdapter.getDefaultAdapter();
        mArrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1);
        setListAdapter(mArrayAdapter);
        connectAsyncTask = new ConnectAsyncTask();
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if(mBluetoothAdapter == null){
            //Device does not support Bluetooth
            Toast.makeText(getApplicationContext(), "Not support bluetooth", Toast.LENGTH_SHORT).show();
            finish();
        }
        if(!mBluetoothAdapter.isEnabled()){
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, 1);
        }
        Set<BluetoothDevice> pariedDevices = mBluetoothAdapter.getBondedDevices();
        if(pariedDevices.size() > 0){
            for(BluetoothDevice device : pariedDevices){
                mArrayAdapter.add(device.getName() + "\n" + device.getAddress());
                btDeviceArray.add(device);
            }
        }
        wv = (WebView) findViewById(R.id.xwv);
        wv.setWebViewClient(new Cliente());
        ws = wv.getSettings();
        ws.setBuiltInZoomControls(true);
        ws.setJavaScriptEnabled(true);
        ws.setUseWideViewPort(true);
        wv.loadUrl(s);
        btn1 = (ToggleButton) findViewById(R.id.btn1);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(btn1.isChecked()){
                    try {
                        StreamThread in = new StreamThread(btSocket, wv);
                        in.write(("1").getBytes());
                        in.start();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

            }
        });

    }

    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
        BluetoothDevice device = btDeviceArray.get(position);
        connectAsyncTask.execute(device);
        Toast.makeText(getApplicationContext(),"Conectado",Toast.LENGTH_SHORT).show();
    }

    private class ConnectAsyncTask extends AsyncTask<BluetoothDevice, Integer, BluetoothSocket>{
        private BluetoothSocket mmSocket;
        private BluetoothDevice mmDevice;
        @Override
        protected BluetoothSocket doInBackground(BluetoothDevice... device) {
            mmDevice = device[0];
            try {
                String mmUUID = "00001101-0000-1000-8000-00805F9B34FB";
                mmSocket = mmDevice.createInsecureRfcommSocketToServiceRecord(UUID.fromString(mmUUID));
                mmSocket.connect();
            } catch (Exception e) { }
            return mmSocket;
        }

        @Override
        protected void onPostExecute(BluetoothSocket result) {
            btSocket = result;
        }
    }
    class Cliente extends WebViewClient {
        public boolean shouldOverrideUrlLoading(WebView view, String url){
            return false;
        }
        public void onPageFinished(WebView view, String url) {

        }
    }

    private class StreamThread extends Thread {

        private InputStream in;
        private OutputStream out;
        private WebView wv;
        String link = "https://catkin-complex-couch.glitch.me/";
        public StreamThread(BluetoothSocket mBluetoothSocket, WebView w) {
            wv = w;
            try {
                in = mBluetoothSocket.getInputStream();
                out = mBluetoothSocket.getOutputStream();
            } catch (IOException e) {
                Log.e("TAG", "Error de variables:" + e.getMessage(), e);
            }
        }

        public void run() {
            byte[] data = new byte[1024];
            int length;
            while (true) {
                try {
                    length = in.read(data);
                    String text = new String(data, 0, length);
                    String[] fin = text.split("\n");
                    if(fin.length>0){
                        while(fin[fin.length-1].indexOf(".00")==-1){
                            length = in.read(buffer);
                            text = new String(buffer, 0, length);
                            fin = text.split("\n");
                        }
                        String linkf = link + "?" + fin[fin.length-1];
                        Log.i("TAG", "Texto:" + linkf);
                        wv.post(new Runnable() {
                            @Override
                            public void run() {
                                wv.loadUrl(linkf);
                            }
                        });
                    }
                    sleep(2000);
                } catch (IOException | InterruptedException e) {
                    Log.e("TAG", "Posible conexión perdida:" + e.getMessage(), e);
                    break;
                }
            }

        }

        public void write(byte[] data) throws IOException {
            out.write(data);
        }
    }
}